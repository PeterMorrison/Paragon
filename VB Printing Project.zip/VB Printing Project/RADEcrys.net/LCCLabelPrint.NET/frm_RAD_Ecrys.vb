Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frm_RAD_Ecrys
	Inherits System.Windows.Forms.Form
	'RAD Crystal Report Viewer
	'Written & Developed by G Finnon
	'January 2010
	'For LCC Pallet Assembly Solution
	
	
	'Function for converting long file names to short file names
	Private Declare Function GetShortPathName Lib "kernel32"  Alias "GetShortPathNameA"(ByVal lpszLongPath As String, ByVal lpszShortPath As String, ByVal cchBuffer As Integer) As Integer
	Public Function GetShortFileName(ByVal long_name As String) As String
		Dim length As Integer
		Dim short_name As String
		short_name = Space(1024)
		length = GetShortPathName(long_name, short_name, Len(short_name))
		GetShortFileName = VB.Left(short_name, length)
	End Function
	
	'Crystal Form
	Private Sub frm_RAD_Ecrys_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Dim X As Object
		Dim Connectioninfo As Object
		Dim dbtable As Object
		Dim Table As Object
		Dim p As Object
		'On loading the form pass the command line switch
		'this is the report to be run
		
		'General Variable Declarations
		Dim Data() As String 'Array for holding command line
		Dim i As Short 'Integer for stepping through commands
		Dim CmdLine As String 'Intended to hold command line
		Dim CmdLine2 As String 'Intended to hold part of command line
		Dim QueueNumber As Integer 'Print Queue number to process
		Dim PrinterFoundCount As Short 'See if we can find printer
		
		'Crystal Reports Variables
		Dim Report As CRAXDRT.Report
		Dim crxApp As CRAXDRT.Application
		'set report object variables
		Dim RepSec As CRAXDRT.Section 'Report Section
		Dim repsecs As CRAXDRT.Sections 'Report Sections
		Dim subrep As CRAXDRT.Report 'Subreport
		Dim RepObj As CRAXDRT.ReportObjects 'Report objects
		Dim SubDbtable As CRAXDRT.DatabaseTable 'Subreport Database table
		Dim SubConnInfo As CRAXDRT.ConnectionProperties 'Subreport connection info
		
		'Connect to EFACS database
		Dim DBConnect1 As clsData
		DBConnect1 = New clsData
		
		'Get the job at the top of the queue
		
		QueueNumber = DBConnect1.GetTopOfQueue
		
		If QueueNumber = 0 Then
			DBConnect1.UpdateQueueItem(QueueNumber, "F")
			Me.Close()
			Exit Sub
		End If
		
		'Set default variabls
		EFName = "efacdb"
		
		'Get details from print queue
		
		If DBConnect1.GetQueueDetails(QueueNumber) = False Then
			DBConnect1.UpdateQueueItem(QueueNumber, "F")
			Me.Close()
			Exit Sub
		End If
		
		'Get label details
		If DBConnect1.GetLabelDetails(Trim(prtcust)) = False Then
			DBConnect1.UpdateQueueItem(QueueNumber, "F")
			Me.Close()
			Exit Sub
			
		End If
		
		PrinterFoundCount = 0
		'Try and locate printer
		'UPGRADE_ISSUE: Printers object was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6B85A2A7-FE9F-4FBE-AA0C-CF11AC86A305"'
		For	Each p In Printers
			'UPGRADE_WARNING: Couldn't resolve default property of object p.DeviceName. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Trim(p.DeviceName) = prtName Then
				PrinterFoundCount = PrinterFoundCount + 1
				Exit For
			End If
		Next p
		
		'If we can find the printer do nothing
		If PrinterFoundCount = 0 Then
			
			DBConnect1.UpdateQueueItem(QueueNumber, "F")
			Me.Close()
			Exit Sub
			
		End If
		
		'Open Crystal Report
		crxApp = New CRAXDRT.Application
		Report = crxApp.OpenReport(prtLabel)
		
		'Set Report Printer
		'UPGRADE_ISSUE: Printers object was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6B85A2A7-FE9F-4FBE-AA0C-CF11AC86A305"'
		For	Each p In Printers
			
			'UPGRADE_WARNING: Couldn't resolve default property of object p.DeviceName. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Trim(p.DeviceName) = prtName Then
				'UPGRADE_WARNING: Couldn't resolve default property of object p.Port. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object p.DeviceName. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object p.DriverName. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				Report.SelectPrinter(p.DriverName, p.DeviceName, p.Port)
				Exit For
			End If
		Next p
		
		'Strip out report database connection details
		'replace with run time database details
		Dim tmpcount As Short
		Dim subtmpcount As Short
		
		tmpcount = 1
		For	Each Table In Report.Database.Tables
			dbtable = Report.Database.Tables(tmpcount)
			'UPGRADE_WARNING: Couldn't resolve default property of object dbtable.ConnectionProperties. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			Connectioninfo = dbtable.ConnectionProperties
			'UPGRADE_WARNING: Couldn't resolve default property of object Connectioninfo.DeleteAll. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			Connectioninfo.DeleteAll()
			'UPGRADE_WARNING: Couldn't resolve default property of object Connectioninfo.Add. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			Connectioninfo.Add("DSN", "efacdb")
			'UPGRADE_WARNING: Couldn't resolve default property of object Connectioninfo.Add. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			Connectioninfo.Add("Database", EFName)
			'UPGRADE_WARNING: Couldn't resolve default property of object Connectioninfo.Add. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			Connectioninfo.Add("Trusted_Connection", 1)
			'UPGRADE_WARNING: Couldn't resolve default property of object Connectioninfo.Add. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			Connectioninfo.Add("UseDSNProperties", 0)
			'UPGRADE_WARNING: Couldn't resolve default property of object dbtable.Location. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			'UPGRADE_WARNING: Couldn't resolve default property of object dbtable.Name. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			dbtable.Location = dbtable.Name
			tmpcount = tmpcount + 1
		Next Table
		
		'Strip out sub report database connection details
		'replace with runtime database details
		repsecs = Report.Sections
		For i = 1 To repsecs.Count
			RepSec = repsecs.Item(i)
			RepObj = RepSec.ReportObjects
			For X = 1 To RepObj.Count
				'UPGRADE_WARNING: Couldn't resolve default property of object RepObj.Item(X).Kind. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If RepObj.Item(X).Kind = CRAXDDRT.CRObjectKind.crSubreportObject Then
					subtmpcount = 1
					'UPGRADE_WARNING: Couldn't resolve default property of object RepObj.Item().SubreportName. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					subrep = Report.OpenSubreport(RepObj.Item(X).SubreportName)
					For	Each Table In subrep.Database.Tables
						SubDbtable = subrep.Database.Tables(subtmpcount)
						SubConnInfo = SubDbtable.ConnectionProperties
						SubConnInfo.DeleteAll()
						SubConnInfo.Add("DSN", "efacdb")
						SubConnInfo.Add("Database", EFName)
						SubConnInfo.Add("Trusted_Connection", 1)
						SubConnInfo.Add("UseDSNProperties", 0)
						SubDbtable.Location = SubDbtable.Name
						subtmpcount = subtmpcount + 1
					Next Table
				End If
			Next 
		Next 
		
		'Analyse report
		Dim PromptNo As Short
		Dim promptcounter As Short
		Dim SuccessCount As Short
		With Report
			promptcounter = .ParameterFields.Count
			PromptNo = 1
			.ParameterFields(PromptNo).AddCurrentValue((prtdelv))
		End With
		
		
		'Run the report
		'disable print combo box
		Report.DisplayProgressDialog = False
		
		
		
		'print out no collation of copies
		Report.PrintOut(False, prtCopies,  , 1, 999)
		
		'Update queue to indicate job done
		DBConnect1.UpdateQueueItem(QueueNumber, "Y")
		Me.Close()
		
		
	End Sub
	
	'UPGRADE_WARNING: Event frm_RAD_Ecrys.Resize may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub frm_RAD_Ecrys_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
		'Allows the crystal control to resize with the form
		CRviewer91.Top = 0
		CRviewer91.Left = 0
		CRviewer91.Height = ClientRectangle.Height
		CRviewer91.Width = ClientRectangle.Width
	End Sub
	
	Private Sub frm_RAD_Ecrys_FormClosed(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
		Dim crxApp As Object
		'UPGRADE_NOTE: Object crxApp may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		crxApp = Nothing
	End Sub
End Class