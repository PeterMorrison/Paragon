Option Strict Off
Option Explicit On
Friend Class clsData
	Dim efacdb As ADODB.Connection
	Dim rs_prtq As ADODB.Recordset
	Dim rs_efprtq As ADODB.Recordset 'Print Queue
	Dim rs_eflabels As ADODB.Recordset 'Label details
	Dim rs_qiu As ADODB.Recordset 'Queue item update
	Dim i As Short 'Counting Variable
	
	Dim EfCustomers As ADODB.Recordset 'EFACS Customer Codes
	Dim EfDBName As ADODB.Recordset 'Current EFACS Database
	Dim EFShare As ADODB.Recordset 'Efacs Share
	
	
	
	'Set connection based on EFACDB dsn
	'UPGRADE_NOTE: Class_Initialize was upgraded to Class_Initialize_Renamed. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
	Private Sub Class_Initialize_Renamed()
		Dim err_title As Object
		Dim cs As Object
		On Error GoTo error_handler
		efacdb = New ADODB.Connection
		'UPGRADE_WARNING: Couldn't resolve default property of object cs. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		cs = "DSN=labelprintdb;UID=;PWD=;"
		'UPGRADE_WARNING: Couldn't resolve default property of object cs. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		efacdb.Open(cs)
		efacdb.CommandTimeout = 30
		Exit Sub
error_handler: 
		'UPGRADE_WARNING: Couldn't resolve default property of object err_title. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		MsgBox("Error " & Err.Number & vbCr & "Check Datasource EFACDB" & vbCr & Err.Description, MsgBoxStyle.Critical, err_title)
	End Sub
	Public Sub New()
		MyBase.New()
		Class_Initialize_Renamed()
	End Sub
	
	Function GetTopOfQueue() As Integer
		Dim sql As Object
		'   initialise recordset
		'UPGRADE_WARNING: Couldn't resolve default property of object sql. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		sql = "select isnull(max(plq_id),0) [plq_id] from bes_plabelq where plq_status = 'N' order by 1 desc"
		rs_prtq = New ADODB.Recordset
		rs_prtq.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
		rs_prtq.LockType = ADODB.LockTypeEnum.adLockOptimistic
		rs_prtq.Open(sql, efacdb,  ,  , ADODB.CommandTypeEnum.adCmdText)
		Do While Not rs_prtq.EOF
			GetTopOfQueue = rs_prtq.Fields("plq_id").Value
			rs_prtq.MoveNext()
		Loop 
		
		rs_prtq.Close()
		'UPGRADE_NOTE: Object rs_prtq may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		rs_prtq = Nothing
		
		
	End Function
	
	
	
	Function GetQueueDetails(ByRef q_id As Integer) As Boolean
		Dim sql As Object
		'   reset counting variable
		i = 0
		'   Initialise recordset
		rs_efprtq = New ADODB.Recordset
		'UPGRADE_WARNING: Couldn't resolve default property of object sql. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		sql = "select plq_id, plq_delv, plg_date, plq_status, plq_cust from bes_plabelq where plq_id = '" & q_id & "'"
		rs_efprtq.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
		rs_efprtq.LockType = ADODB.LockTypeEnum.adLockOptimistic
		rs_efprtq.Open(sql, efacdb,  ,  , ADODB.CommandTypeEnum.adCmdText)
		'   Get Delivery Number and Customer ID
		Do While Not rs_efprtq.EOF
			prtcust = rs_efprtq.Fields("plq_cust").Value
			prtdelv = rs_efprtq.Fields("plq_delv").Value
			i = i + 1
			rs_efprtq.MoveNext()
		Loop 
		rs_efprtq.Close()
		'UPGRADE_NOTE: Object rs_efprtq may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		rs_efprtq = Nothing
		
		'Check to see if we had any records returned
		If i = 0 Then
			GetQueueDetails = False
		Else
			GetQueueDetails = True
		End If
	End Function
	
	Function GetLabelDetails(ByRef cust As String) As Boolean
		Dim sql As Object
		'   reset counting variable
		i = 0
		'   Initialise recordset
		rs_eflabels = New ADODB.Recordset
		'UPGRADE_WARNING: Couldn't resolve default property of object sql. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		sql = "select pl_cust, pl_label, pl_printer, pl_copies from bes_plabels where pl_cust = '" & cust & "'"
		rs_eflabels.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
		rs_eflabels.LockType = ADODB.LockTypeEnum.adLockOptimistic
		rs_eflabels.Open(sql, efacdb,  ,  , ADODB.CommandTypeEnum.adCmdText)
		'   Get Delivery Number and Customer ID
		Do While Not rs_eflabels.EOF
			prtLabel = Trim(rs_eflabels.Fields("pl_label").Value)
			prtCopies = rs_eflabels.Fields("pl_copies").Value
			prtName = Trim(rs_eflabels.Fields("pl_printer").Value)
			i = i + 1
			rs_eflabels.MoveNext()
		Loop 
		rs_eflabels.Close()
		'UPGRADE_NOTE: Object rs_eflabels may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		rs_eflabels = Nothing
		
		'Check to see if we had any records returned
		If i = 0 Then
			GetLabelDetails = False
		Else
			GetLabelDetails = True
		End If
	End Function
	
	Sub UpdateQueueItem(ByRef q_no As Integer, ByRef q_status As String)
		Dim sql As Object
		rs_qiu = New ADODB.Recordset
		'UPGRADE_WARNING: Couldn't resolve default property of object sql. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		sql = "update bes_plabelq set plq_status = '" & q_status & "' where plq_id = '" & q_no & "'"
		rs_qiu.CursorType = ADODB.CursorTypeEnum.adOpenKeyset
		rs_qiu.LockType = ADODB.LockTypeEnum.adLockOptimistic
		'UPGRADE_WARNING: Couldn't resolve default property of object sql. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		rs_qiu = efacdb.Execute(sql)
		'rs_qiu.Close
		'UPGRADE_NOTE: Object rs_qiu may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
		rs_qiu = Nothing
	End Sub
End Class