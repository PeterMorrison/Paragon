Option Strict Off
Option Explicit On
Module Main
	Public prtcust As String 'EFACS Customer ID
	Public prtdelv As Integer 'EFACS Delivery Number
	Public prtName As String 'Printer Name
	Public prtLabel As String 'Printer Label
	Public prtCopies As Short 'Number of Copies
	Public EFName As String 'Name of EFACS Database connected to
End Module