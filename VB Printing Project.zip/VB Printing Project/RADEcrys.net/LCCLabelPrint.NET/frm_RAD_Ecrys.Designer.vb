<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frm_RAD_Ecrys
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents CRviewer91 As AxCrystalActiveXReportViewerLib11.AxCrystalActiveXReportViewer
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frm_RAD_Ecrys))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.CRviewer91 = New AxCrystalActiveXReportViewerLib11.AxCrystalActiveXReportViewer
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.CRviewer91, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.Text = "RAD Ecrys"
		Me.ClientSize = New System.Drawing.Size(921, 604)
		Me.Location = New System.Drawing.Point(4, 23)
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frm_RAD_Ecrys"
		CRviewer91.OcxState = CType(resources.GetObject("CRviewer91.OcxState"), System.Windows.Forms.AxHost.State)
		Me.CRviewer91.Size = New System.Drawing.Size(905, 585)
		Me.CRviewer91.Location = New System.Drawing.Point(8, 8)
		Me.CRviewer91.TabIndex = 0
		Me.CRviewer91.Name = "CRviewer91"
		Me.Controls.Add(CRviewer91)
		CType(Me.CRviewer91, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class